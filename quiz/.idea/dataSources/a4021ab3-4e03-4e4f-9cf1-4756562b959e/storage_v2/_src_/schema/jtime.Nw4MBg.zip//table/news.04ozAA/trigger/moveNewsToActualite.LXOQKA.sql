create trigger moveNewsToActualite
  before INSERT
  on news
  for each row
  INSERT INTO actualite(fk_admin, texte, date_envoie) VALUES (new.fk_admin, new.texte, now());


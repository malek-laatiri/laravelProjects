create trigger moveTemoignageAToActualite
  before INSERT
  on temoignage_donneur
  for each row
  INSERT INTO actualite(fk_association, texte, date_envoie) VALUES (new.fk_association, new.temoignage, now());


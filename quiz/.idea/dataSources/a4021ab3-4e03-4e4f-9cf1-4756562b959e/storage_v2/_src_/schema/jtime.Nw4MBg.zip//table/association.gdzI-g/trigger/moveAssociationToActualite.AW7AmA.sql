create trigger moveAssociationToActualite
  before UPDATE
  on association
  for each row
begin 
if new.etat = 1 AND old.accepted_once != 1 then 
insert into actualite(texte, date_envoie) values (concat("l'association ", new.nom, " vien de rejoindre Jtime !"), now()); 

end if ;
end;


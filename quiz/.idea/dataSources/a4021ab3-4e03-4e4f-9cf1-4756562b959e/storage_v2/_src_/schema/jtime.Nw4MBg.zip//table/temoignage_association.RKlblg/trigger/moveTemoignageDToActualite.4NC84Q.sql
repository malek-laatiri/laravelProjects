create trigger moveTemoignageDToActualite
  before INSERT
  on temoignage_association
  for each row
  INSERT INTO actualite(fk_donneur, texte, date_envoie) VALUES (new.fk_donneur, new.temoignage, now());


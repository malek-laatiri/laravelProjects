create definer = root@localhost event deleteMailExpire on schedule
  every '1' DAY
    starts '2021-05-16 18:27:59'
  enable
  do
  DELETE FROM recuperation WHERE CURRENT_DATE >= dateFin;


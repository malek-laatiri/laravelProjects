create view dossier as
select `jtime`.`requete`.`id_requete`           AS `id_requete`,
       `jtime`.`requete`.`etape`                AS `etape`,
       `jtime`.`donneur`.`id_donneur`           AS `id_donneur`,
       `jtime`.`association`.`id_association`   AS `id_association`,
       `jtime`.`beneficiaire`.`id_beneficiaire` AS `id_beneficiaire`,
       `jtime`.`beneficiaire`.`photo`           AS `photo`,
       `jtime`.`beneficiaire`.`prenom`          AS `prenom`,
       `jtime`.`donneur`.`prenom`               AS `prenom_donneur`,
       `jtime`.`beneficiaire`.`nom`             AS `nom`,
       `jtime`.`donneur`.`nom`                  AS `nom_donneur`,
       `jtime`.`donneur`.`photo`                AS `photo_donneur`,
       `jtime`.`beneficiaire`.`histoire`        AS `histoire`,
       `jtime`.`ville`.`ville_nom`              AS `ville_nom`,
       `jtime`.`ville`.`ville_code_postal`      AS `ville_code_postal`,
       `jtime`.`association`.`logo`             AS `logo`,
       `jtime`.`association`.`nom`              AS `nom_association`,
       `jtime`.`association`.`email`            AS `email_association`,
       `jtime`.`association`.`contact_nom`      AS `contact_nom`,
       `jtime`.`association`.`contact_prenom`   AS `contact_prenom`,
       `jtime`.`association`.`contact_email`    AS `contact_email`
from ((((`jtime`.`requete` join `jtime`.`beneficiaire`) join `jtime`.`association`) join `jtime`.`donneur`)
       join `jtime`.`ville` on (((`jtime`.`requete`.`fk_beneficiaire` = `jtime`.`beneficiaire`.`id_beneficiaire`) and
                                 (`jtime`.`requete`.`fk_association` = `jtime`.`association`.`id_association`) and
                                 (`jtime`.`requete`.`fk_donneur` = `jtime`.`donneur`.`id_donneur`) and
                                 (`jtime`.`beneficiaire`.`ville` = `jtime`.`ville`.`ville_id`))));

